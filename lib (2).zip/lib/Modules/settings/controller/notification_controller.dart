﻿import 'package:get/get.dart';
import '../model/notifications_model.dart';
import 'package:Gixa/services/appnotification_services.dart';
import 'package:Gixa/network/app_exception.dart';
import 'package:Gixa/common/widgets/app_snackbar.dart';

class NotificationController extends GetxController {
  final isLoading = false.obs;
  final Rxn<NotificationSettingsModel> settings =
      Rxn<NotificationSettingsModel>();

  final NotificationApiService _service = NotificationApiService();

  @override
  void onInit() {
    super.onInit();
    fetchSettings();
  }

  // â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  // ðŸ”” FETCH SETTINGS
  // â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  Future<void> fetchSettings() async {
    try {
      isLoading.value = true;

      final result = await _service.fetchNotificationSettings();

      settings.value = result;
    } catch (e) {
      AppSnackbar.show("Error", "Failed to load notification settings");
    } finally {
      isLoading.value = false;
    }
  }

  // â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  // ðŸ”„ UPDATE SINGLE TOGGLE
  // â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  Future<void> updateField({
    required String type,
    required String channel,
    required bool value,
  }) async {
    if (settings.value == null) return;

    final oldValue = channel == "EMAIL"
        ? settings.value!.email[type] ?? false
        : settings.value!.push[type] ?? false;

    /// Optimistic update
    settings.update((data) {
      if (data == null) return;

      if (channel == "EMAIL") {
        if (data.email.containsKey(type)) {
          data.email[type] = value;
        }
      } else {
        if (data.push.containsKey(type)) {
          data.push[type] = value;
        }
      }
    });

    try {
      await _service.updateNotificationSettings(
        type: type,
        channel: channel,
        isEnabled: value,
      );
    } on AppException catch (e) {
      /// Rollback
      settings.update((data) {
        if (data == null) return;

        if (channel == "EMAIL") {
          data.email[type] = oldValue;
        } else {
          data.push[type] = oldValue;
        }
      });

      AppSnackbar.show("Error", e.message);
    } catch (e) {
      /// Rollback
      settings.update((data) {
        if (data == null) return;

        if (channel == "EMAIL") {
          data.email[type] = oldValue;
        } else {
          data.push[type] = oldValue;
        }
      });

      AppSnackbar.show("Update Failed", "Unable to update setting");
    }
  }
}

